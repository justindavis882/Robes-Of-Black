const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);
const osc = require('osc');
const fs = require('fs');
const path = require('path');

app.use(express.static('public'));

const udpPort = new osc.UDPPort({
    localAddress: "0.0.0.0", 
    localPort: 8000, // Make sure Reaper is sending to this port on the new laptop's IP
    metadata: true
});

udpPort.on("message", function (oscMsg) {
    if (oscMsg.address === "/lastmarker/name") {
        const markerString = oscMsg.args[0].value;
        
        if (markerString.startsWith("SONG:")) {
            const songId = markerString.replace("SONG:", "").trim();
            const filePath = path.join(__dirname, 'lyrics', `${songId}.json`);

            fs.readFile(filePath, 'utf8', (err, data) => {
                if (err) {
                    console.error(`❌ Could not find lyrics for: ${songId}`);
                    io.emit('load_error', `Lyrics not found for ${songId}`);
                    return;
                }
                
                const songData = JSON.parse(data);
                console.log(`🎵 Loaded Song: ${songData.title}`);
                io.emit('load_song', songData);
            });
            
        } else {
            console.log(`➡️ Section: ${markerString}`);
            io.emit('section_change', markerString); 
        }
    }
});

udpPort.open();

http.listen(3000, () => {
    console.log('Teleprompter Server running at http://localhost:3000');
});